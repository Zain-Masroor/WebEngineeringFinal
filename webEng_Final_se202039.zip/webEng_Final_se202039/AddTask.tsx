// AddTask.tsx
import React, { useState } from 'react';
import './AddTask.css';

interface Task {
  name: string;
  details: string;
  priority: string;
  deadline: string;
}

const AddTask: React.FC<{ addTask: (task: Task) => void }> = ({ addTask }) => {
  const [taskName, setTaskName] = useState('');
  const [taskDetails, setTaskDetails] = useState('');
  const [taskPriority, setTaskPriority] = useState('low');
  const [taskDeadline, setTaskDeadline] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (taskName.trim() && taskDetails.trim() && taskDeadline.trim()) {
      addTask({ name: taskName, details: taskDetails, priority: taskPriority, deadline: taskDeadline, finished: false });
      setTaskName('');
      setTaskDetails('');
      setTaskPriority('low');
      setTaskDeadline('');
    }
  };

  return (
    <div className="add-task-form">
      <h2>Add Task</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="taskName">Task Name:</label>
          <input type="text" id="taskName" value={taskName} onChange={(e) => setTaskName(e.target.value)} />
        </div>
        <div className="form-group">
          <label htmlFor="taskDetails">Task Details:</label>
          <textarea id="taskDetails" value={taskDetails} onChange={(e) => setTaskDetails(e.target.value)} />
        </div>
        <div className="form-group">
          <label htmlFor="taskPriority">Task Priority:</label>
          <select id="taskPriority" value={taskPriority} onChange={(e) => setTaskPriority(e.target.value)}>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="taskDeadline">Deadline:</label>
          <input type="date" id="taskDeadline" value={taskDeadline} onChange={(e) => setTaskDeadline(e.target.value)} />
        </div>
        <button type="submit">Add Task</button>
      </form>
    </div>
  );
}

export default AddTask;

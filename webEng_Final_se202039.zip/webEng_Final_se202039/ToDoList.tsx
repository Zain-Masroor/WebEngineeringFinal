// ToDoList.tsx
import React from 'react';
import './ToDoList.css';

interface Task {
  name: string;
  details: string;
  priority: string;
  deadline: string;
  finished: boolean;
}

const ToDoList: React.FC<{ tasks: Task[], markAsFinished: (index: number) => void, clearTask: (index: number) => void }> = ({ tasks, markAsFinished, clearTask }) => {
  const pendingTasks = tasks.filter(task => !task.finished).length;

  return (
    <div className="to-do-list">
      <h2>To-Do List</h2>
      <div className="pending">Pending Tasks: {pendingTasks}</div>
      <table>
        <thead>
          <tr>
            <th>Priority</th>
            <th>Task Name</th>
            <th>Task Details</th>
            <th>Deadline</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {tasks.map((task, index) => (
            <tr key={index}>
              <td>
                <div className={`priority ${task.priority}`}></div>
              </td>
              <td>{task.name}</td>
              <td>{task.details}</td>
              <td>{task.deadline}</td>
              <td>
                <label className="switch">
                  <input type="checkbox" checked={task.finished} onChange={() => markAsFinished(index)} />
                  <span className="slider"></span>
                </label>
                <button className="clear" onClick={() => clearTask(index)}>❌</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ToDoList;

import React, { useState } from 'react';
import AddTask from './AddTask';
import ToDoList from './ToDoList';
import './App.css';

interface Task {
  name: string;
  details: string;
  priority: string;
  deadline: string;
  finished: boolean;
}

const App: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);

  const addTask = (task: Task) => {
    setTasks([...tasks, task]);
  };

  const markAsFinished = (index: number) => {
    const updatedTasks = [...tasks];
    updatedTasks[index].finished = !updatedTasks[index].finished;
    setTasks(updatedTasks);
  };

  const clearTask = (index: number) => {
    const updatedTasks = [...tasks];
    updatedTasks.splice(index, 1);
    setTasks(updatedTasks);
  };

  return (
    <div className="container">
      <div className="content">
        <div className="add-task">
          <AddTask addTask={addTask} />
        </div>
        <div className="to-do-list">
          <ToDoList tasks={tasks} markAsFinished={markAsFinished} clearTask={clearTask} />
        </div>
      </div>
    </div>
  );
}

export default App;
